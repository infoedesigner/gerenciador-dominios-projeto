import axios from 'axios';
import { useEffect, useState } from 'react';

type Dominio = {
  id: number;
  nome: string;
  dominio: string;
  cliente: string;
  ativo: boolean;
  data_registro: string;
  data_expiracao: string;
  observacoes: string;
};

export default function Home() {
  const [dominios, setDominios] = useState<Dominio[]>([]);

  useEffect(() => {
    axios.get('http://localhost:8000/api/dominios')
      .then(res => setDominios(res.data));
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Domínios Registrados</h1>
      <table className="w-full border">
        <thead>
          <tr>
            <th className="border p-2">Nome</th>
            <th className="border p-2">Domínio</th>
            <th className="border p-2">Cliente</th>
            <th className="border p-2">Ativo</th>
          </tr>
        </thead>
        <tbody>
          {dominios.map(dom => (
            <tr key={dom.id}>
              <td className="border p-2">{dom.nome}</td>
              <td className="border p-2">{dom.dominio}</td>
              <td className="border p-2">{dom.cliente}</td>
              <td className="border p-2">{dom.ativo ? 'Sim' : 'Não'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
