<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Dominio;
use Illuminate\Http\Request;

class DominioController extends Controller
{
    public function index() {
        return Dominio::all();
    }

    public function store(Request $request) {
        $validated = $request->validate([
            'nome' => 'required|string|max:255',
            'dominio' => 'required|string|unique:dominios',
            'cliente' => 'required|string',
            'ativo' => 'required|boolean',
            'data_registro' => 'required|date',
            'data_expiracao' => 'required|date',
            'observacoes' => 'nullable|string',
        ]);
        return Dominio::create($validated);
    }

    public function show($id) {
        return Dominio::findOrFail($id);
    }

    public function update(Request $request, $id) {
        $dominio = Dominio::findOrFail($id);
        $dominio->update($request->all());
        return $dominio;
    }

    public function destroy($id) {
        Dominio::destroy($id);
        return response()->noContent();
    }
}
