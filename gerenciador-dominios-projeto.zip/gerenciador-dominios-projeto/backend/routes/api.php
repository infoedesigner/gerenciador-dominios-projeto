<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\DominioController;

Route::apiResource('dominios', DominioController::class);
